package com.scb.evaluation.coding.util;

import com.scb.evaluation.coding.dto.Trade;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.util.ArrayList;
import java.util.List;


public class CommonUtils {

    public static final String TRADE_FILE_TYPE = "text/csv";

    public static boolean hasCSVFormat(String contentType) {
        if (!TRADE_FILE_TYPE.equals(contentType)) {
            return false;
        }
        return true;
    }

    public static List<CSVRecord> csvToRecords(InputStream is, String[] headers) {
        CSVFormat format = CSVFormat.Builder.create().setHeader(headers).setSkipHeaderRecord(true).setIgnoreHeaderCase(true).setTrim(true).build();
        try (BufferedReader fileReader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
             CSVParser csvParser = new CSVParser(fileReader,
                     format);) {
            List<Trade> trades = new ArrayList<Trade>();
            List<CSVRecord> csvRecords = csvParser.getRecords();
            return csvRecords;
        } catch (Exception e) {
            throw new RuntimeException("Failed to parse CSV file!");
        }
    }


    public static boolean isValidDate(String dateString, String pattern) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern).withResolverStyle(ResolverStyle.STRICT);
        try {
            formatter.parse(dateString);
        } catch (DateTimeParseException e) {
            return false;
        }
        return true;
    }

}
