package com.scb.evaluation.coding.service;

import com.scb.evaluation.coding.dto.Trade;
import com.scb.evaluation.coding.util.CommonUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.csv.QuoteMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

@Service
@Slf4j
public class TradeServiceImpl implements TradeService {

    private static final String[] TRADE_HEADERS = {"date", "product_id", "currency", "price"};
    private static final String[] ENRICHED_TRADE_HEADERS = {"date", "product_name", "currency", "price"};
    private static final String[] PRODUCT_HEADERS = {"product_id", "product_name"};

    private static final CSVFormat FORMAT = CSVFormat.Builder.create()
            .setHeader(ENRICHED_TRADE_HEADERS).build();

    @Autowired
    private ResourceLoader resourceLoader;

    private Map<String, String> productMap;

    @Override
    public void enrichTradeData(HttpServletRequest request, HttpServletResponse response) throws Exception {
        if (!CommonUtils.hasCSVFormat(request.getContentType())) {
            log.error("Please upload a csv file.");
            throw new Exception("Please upload a csv file.");
        }
        String enrichedCsv = "enriched_trade.csv";
        List<Trade> enrichedTrades = new ArrayList<>();
        List<CSVRecord> CSVRecords = CommonUtils.csvToRecords(request.getInputStream(), TRADE_HEADERS);
        CSVRecords.forEach(csvRecord -> {
            Trade trade = Trade.builder().date(csvRecord.get("date")).product_id(csvRecord.get("product_id")).product_name(productMap.get(csvRecord.get("product_id"))).currency(csvRecord.get("currency")).price(csvRecord.get("price")).build();
            if (CommonUtils.isValidDate(trade.getDate(), "uuuuMMdd")) {
                enrichedTrades.add(trade);
            } else {
                log.error("Trade " + trade + " contains invalid date");
            }

        });
        writeToCSV(enrichedTrades, response.getWriter());
        response.setContentType(CommonUtils.TRADE_FILE_TYPE);
        response.addHeader("Content-Disposition", "attachment; filename=" + enrichedCsv);
    }

    private void writeToCSV(List<Trade> enrichedTrades, PrintWriter writer) {
        CSVFormat format = CSVFormat.Builder.create().setQuoteMode(QuoteMode.MINIMAL).build();

        try (CSVPrinter csvPrinter = new CSVPrinter(writer, FORMAT);) {
            for (Trade trade : enrichedTrades) {
                List<String> data = Arrays.asList(
                        trade.getDate(),
                        trade.getProduct_name(),
                        trade.getCurrency(),
                        trade.getPrice()
                );
                csvPrinter.printRecord(data);
            }
            csvPrinter.flush();
        } catch (IOException e) {
            throw new RuntimeException("fail to convert data to CSV file: " + e.getMessage());
        }
    }


    @PostConstruct
    private void loadProductData() throws Exception {
        productMap = new HashMap<String, String>();
        Resource resource = resourceLoader.getResource("classpath:product.csv");
        List<CSVRecord> csvRecords = CommonUtils.csvToRecords(resource.getInputStream(), PRODUCT_HEADERS);
        for (CSVRecord csvRecord : csvRecords) {
            productMap.put(csvRecord.get("product_id"), csvRecord.get("product_name"));
        }

    }
}
