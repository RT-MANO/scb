package com.scb.evaluation.coding.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class Trade {
    private String date;
    private String product_id;
    private String product_name;
    private String currency;
    private String price;

}
