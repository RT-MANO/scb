package com.scb.evaluation.coding.controller;

import com.scb.evaluation.coding.service.TradeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@CrossOrigin("http://localhost:8080")
@RestController
public class TradeController {

    @Autowired
    TradeService tradeService;

    @PostMapping("/enrich")
    public void enrichTradeFile(HttpServletRequest request, HttpServletResponse response) throws Exception {
        try {
            tradeService.enrichTradeData(request, response);
        } catch (Exception e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, e.getMessage());
        }
    }

}
