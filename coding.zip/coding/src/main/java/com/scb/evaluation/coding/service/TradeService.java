package com.scb.evaluation.coding.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface TradeService {
    void enrichTradeData(HttpServletRequest request, HttpServletResponse response) throws Exception;
}
