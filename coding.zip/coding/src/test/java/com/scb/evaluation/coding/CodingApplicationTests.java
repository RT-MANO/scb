package com.scb.evaluation.coding;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodingApplicationTests {

	@Test
	void contextLoads() {
	}

}
