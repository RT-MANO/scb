package com.scb.evaluation.coding.util;

import org.apache.commons.csv.CSVRecord;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class CommonUtilsTest {

    @Test
    public void hasCSVFormatTest(){
        assertTrue(CommonUtils.hasCSVFormat("text/csv"));
        assertFalse(CommonUtils.hasCSVFormat("application/json"));
    }

    @Test
    public void isValidDateTest(){
        assertTrue(CommonUtils.isValidDate("20220703", "uuuuMMdd"));
        assertFalse(CommonUtils.isValidDate("2022073", "uuuuMMdd"));
        assertFalse(CommonUtils.isValidDate("20221503", "uuuuMMdd"));
        assertFalse(CommonUtils.isValidDate("20220735", "uuuuMMdd"));
        assertFalse(CommonUtils.isValidDate("202X073", "uuuuMMdd"));
    }


    @Test
    public void csvToRecordsTest() throws Exception {
        String[] headers = {"date", "product_id", "currency", "price"};
        InputStream is = new FileInputStream(new File("src/test/resources/trade_test.csv"));
        List<CSVRecord> csvRecords = CommonUtils.csvToRecords(is, headers);
        assertEquals(3, csvRecords.size());

    }

    @Test
    public void csvToRecordsTestForFailure() {
        String[] headers = {"date", "product_id", "currency", "price"};
        InputStream is = null;
        assertThrows(RuntimeException.class, () ->{
            CommonUtils.csvToRecords(is, headers);
        });

    }

}
