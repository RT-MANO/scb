package com.scb.evaluation.coding.controller;

import com.scb.evaluation.coding.service.TradeService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest
public class TradeControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private TradeService tradeService;

    @Test
    public void enrichTradeFileTestForSuccess() throws Exception {
        doNothing().when(tradeService).enrichTradeData(any(), any());
        this.mockMvc.perform(post("/enrich").content("data".getBytes())).andExpect(status().isOk());
        verify(tradeService, times(1)).enrichTradeData(any(), any());

    }

    @Test
    public void enrichTradeFileTestForFailure() throws Exception {
        doThrow(new Exception("Invalid content type")).when(tradeService).enrichTradeData(any(), any());
        this.mockMvc.perform(post("/enrich").content("data".getBytes())).andExpect(status().isBadRequest());
        verify(tradeService, times(1)).enrichTradeData(any(), any());

    }
}
